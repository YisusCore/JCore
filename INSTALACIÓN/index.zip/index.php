<?php
//===================================================================//
// Este archivo debe ser copiado junto al .htaccess en la carpeta    //
// raiz que dará inicio a la aplicación, así mismo debe modificar    //
// la variable SUBPATH de este archivo indicando la subcarpeta real  //
// donde se encuentra alojada los archivos de la aplicación.         //
//===================================================================//

/**
 * DIRECTORY_SEPARATOR
 *
 * Separador de Directorios para el sistema operativo de ejecución
 *
 * @global
 */
define('DS', DIRECTORY_SEPARATOR);

/**
 * DIRECTORIO DEL SITIO
 *
 * Directorio Raiz de donde es leído el app
 *
 * WARNING: No debe finalizar en DS (Directory Separator)
 *
 * @global
 */
define('HOMEPATH', __DIR__);


/**
 * SUBDIRECTORIO DEL SITIO
 *
 * Subdirectorio donde se encuentra alojado los archivos de la aplicación
 *
 * Si variable SUBPATH se encuentra vacío entonces la aplicación se 
 * encuentra alojada en la misma carpeta del sitio.
 *
 * WARNING: No debe finalizar pero si empezar con DS (Directory Separator)
 *
 * @global
 */
define('SUBPATH', DS);


/**
 * DIRECTORIO ABSOLUTO DEL SITIO
 *
 * Carpeta donde se encuentra alojado los archivos de la aplicación
 *
 * @global
 */
define('ABSPATH', realpath(HOMEPATH . SUBPATH));


/**
 * DIRECTORIO PROCESOS DE APLICACIÓN
 *
 * La variable contiene la ruta a la carpeta que contiene las 
 * funciones {@link https://jcore.jys.pe/functions}, 
 * configuraciones {@link https://jcore.jys.pe/configs}, 
 * objetos {@link https://jcore.jys.pe/objects}, 
 * procesadores {@link https://jcore.jys.pe/processers} y 
 * pantallas {@link https://jcore.jys.pe/displays} de la aplicación.
 *
 * *DIRECTORIOS EN LA CARPETA*
 * * functions, almacena todas los archivos de las funciones
 * * class, almacena todos los archivos de las clases
 * * libs, almacena todos los archivos de las librerías
 * * config, almacena todos los archivos que afectan a la configuración
 * * processors, almacena todos los archivos procesadores
 * * displays, almacena todos los archivos encargados de manipular el contenido del RESPONSE
 * * templates, almacena partes html/php de vistas repetibles
 *
 * WARNING: No debe finalizar en DS (Directory Separator)
 *
 * @internal
 */
define('APPPATH', realpath(ABSPATH . DS . 'APP'));


/**
 * ENVIRONMENT - AMBIENTE DE DESARROLLO
 *
 * Permite manejar distintas configuraciones dependientemente de 
 * la etapa o fase en la que se encuentre la aplicación (proyecto)
 *
 * **Posibles valores:**
 * *	desarrollo
 * *	pruebas
 * *	produccion
 *
 * @global
 */
## define('ENVIRONMENT', 'produccion');


/**
 * DIRECTORIO NÚCLEO JCORE
 *
 * La variable contiene la ruta a la carpeta del núcleo JCore.
 * WARNING: No debe finalizar en DS (Directory Separator)
 *
 * @internal
 */
$JCore_file = '/JCore/v3.2/JCore.php';


//===================================================================//
// NO CAMBIAR EL ARCHIVO A PARTIR DE ESTE PUNTO                      //
//===================================================================//

if( ! file_exists($JCore_file))
{
	die('<br /><b>Fatal Error:</b> Archivo `'. basename($JCore_file, '.php') .'` not exists');
}

require_once $JCore_file;