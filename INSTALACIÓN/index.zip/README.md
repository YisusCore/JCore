# JCore

Copyright (c) 2018 - 2023, JYS Perú

Se otorga permiso, de forma gratuita, a cualquier persona que obtenga una copia de este software y archivos de documentación asociados (el "Software"), para tratar el Software sin restricciones, incluidos, entre otros, los derechos de uso, copia, modificación y fusión, publicar, distribuir, sublicenciar y / o vender copias del Software, y permitir a las personas a quienes se les proporciona el Software que lo hagan, sujeto a las siguientes condiciones:

El aviso de copyright anterior y este aviso de permiso se incluirán en todas las copias o porciones sustanciales del software.

EL SOFTWARE SE PROPORCIONA "TAL CUAL", SIN GARANTÍA DE NINGÚN TIPO, EXPRESA O IMPLÍCITA, INCLUIDAS, ENTRE OTRAS, LAS GARANTÍAS DE COMERCIABILIDAD, IDONEIDAD PARA UN PROPÓSITO PARTICULAR Y NO INFRACCIÓN.<br>
EN NINGÚN CASO LOS AUTORES O PROPIETARIOS DE DERECHOS DE AUTOR SERÁN RESPONSABLES DE CUALQUIER RECLAMO, DAÑO O CUALQUIER OTRO TIPO DE RESPONSABILIDAD, YA SEA EN UNA ACCIÓN CONTRACTUAL, AGRAVIO U OTRO, DERIVADOS, FUERA DEL USO DEL SOFTWARE O EL USO U OTRAS DISPOSICIONES DEL SOFTWARE.


> @author		YisusCore<br>
@link		https://jcore.jys.pe/jcore<br>
@version		1.0.0<br>
@copyright	Copyright (c) 2018 - 2023, JYS Perú (https://www.jys.pe/)<br>

## Instalación

1. Crear un archivo `index.php` en el directorio de acceso a la aplicación **(LLEGADA DEL LINK)**:

2. Definir una variable `HOMEPATH` con el valor `__DIR__`

3. Definir una variable `SUBPATH` con el nombre del subdirectorio donde se encuentra alojado los archivos de la aplicación<br><small>Debe empezar con `DIRECTORY_SEPARATOR` aún si el directorio es el mismo</small>

4. <small><b>(OPCIONAL)</b></small>, La variable `ABSPATH` siempre debe ser el valor `realpath(HOMEPATH . SUBPATH)`

5. <small><b>(OPCIONAL)</b></small>, Definir la variable `APPPATH`  con la ruta del directorio donde se encuentra los archivos de configuración y procesadores de la aplicación<br><small>Por defecto equivale a la variable `ABSPATH`</small>

6. <small><b>(OPCIONAL)</b></small>, Definir la variable `ENVIRONMENT`  con el ambiente actual de desarrollo<br><small>Por defecto equivale `desarrollo`</small>

7. Llamar al archivo `/JCore/v[Versión Actual]/JCore.php`
